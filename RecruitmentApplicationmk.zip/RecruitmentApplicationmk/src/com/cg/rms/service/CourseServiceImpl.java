package com.cg.rms.service;

import java.util.List;

import com.cg.rms.dao.RecruitmentDao;
import com.cg.rms.dao.RecruitmentDaoImpl;
import com.cg.rms.dto.CandidateBeanPersonal;
import com.cg.rms.dto.CandidateBeanQualification;
import com.cg.rms.dto.CandidateBeanWorkHistory;
import com.cg.rms.dto.CompanyMaster;
import com.cg.rms.exception.RecruitmentException;


public class CourseServiceImpl implements CourseService {

	private RecruitmentDao cdao  = new RecruitmentDaoImpl(); 
	
	
	
	@Override
	public String insertCourse(CandidateBeanPersonal cource) throws RecruitmentException {
		
		return cdao.insertCourse(cource);
	}
	
	
	
	@Override
	public String insertCandidateBeanWorkHistory(CandidateBeanWorkHistory chistory)
			throws RecruitmentException {
	
		return cdao.insertCandidateWorkHistory(chistory);
	}
	
	
	@Override
	public String insertCandidateBeanQualification( CandidateBeanQualification cqualifications)
			throws RecruitmentException {
	
		return cdao.insertCandidateQualifications(cqualifications);
	}
	
	
	
	@Override
	public List<CandidateBeanPersonal> getAllCourses() throws RecruitmentException {
		
		return cdao.gatAllCourses();
	}
	@Override
	public boolean updateCourse(CandidateBeanPersonal cource) throws RecruitmentException {
		
	
		return cdao.updateCourse(cource);
	}



	@Override
	public int login(String username, String password, String role)
			throws RecruitmentException {
		
		return cdao.login(username, password, role);
	}



	@Override
	public boolean updateCandidateBeanQualification(
			CandidateBeanQualification cqualifications)
			throws RecruitmentException {
		
		return cdao.updateCandidateQualifications(cqualifications);
	}



	@Override
	public boolean updatCandidateBeanWorkHistory(CandidateBeanWorkHistory chistory)
			throws RecruitmentException {
		
		return cdao.updatCandidateWorkHistory(chistory);
	}


	@Override
	public String addCompanyDetails(CompanyMaster cmaster) throws RecruitmentException {
		// TODO Auto-generated method stub
		return cdao.addCompanyDetails(cmaster);
	}



	@Override
	public boolean updateCompanyDetails() throws RecruitmentException {
		// TODO Auto-generated method stub
		return cdao.updateCompanyDetails();
	}
	@Override
	public List<CandidateBeanQualification> searchjobs(String jreq)
			throws RecruitmentException {
		// TODO Auto-generated method stub
		return cdao.searchjobs(jreq);
	}

	@Override
	public List<CandidateBeanWorkHistory> searchjobs2(String jreq)
			throws RecruitmentException {
		// TODO Auto-generated method stub
		return cdao.searchjobs2(jreq);
	}


	



	
	
	
}
