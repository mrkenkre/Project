package com.cg.rms.UI;

import java.util.Scanner;

import com.cg.rms.exception.RecruitmentException;

public class RecruitmentMain {
	
	
	public static void main(String[] args) throws RecruitmentException {
		
		
		
		
		System.out.println("\t\t\t\t\t\t\t\t\t*****Welcome to Recruitment Management System******");
		System.out.println("\n");
		
		
		Scanner sc = new Scanner(System.in);
		int choice=0;
		
		while(true)
		{
			System.out.println("select User type");
			System.out.println("\n");
			
System.out.println(" 1) Admin Login \n 2) Candidate Login \n 3) Company Login \n");

System.out.println("Enter your Choice");
choice=sc.nextInt();

switch (choice) {
case 1: AdminUI aui = new AdminUI();
aui.adminUimethod();
	
	break;
	
	
case 2: CandidateUI cui = new CandidateUI();
cui.candidateUimethod();

case 3:CompanyUI coui = new CompanyUI();
  coui.companyUimethod();

default: System.exit(0);
	break;
}
			
        }
	}

}
